void race(ALLEGRO_FS_ENTRY *track_file_entry, CONFIG* config, ALLEGRO_DISPLAY* disp);
